<?php
// ToDo: SQL Zugangsdaten an eure DB anpassen
$link = mysqli_connect();

if (!$link) {
    die('Verbindungsfehler: (' . mysqli_connect_errno() . ') '
        . mysqli_connect_error());
}

mysqli_set_charset($link, 'utf8');

?>