<h3>Vielen Dank für deine Anmeldung</h3>
<p>Du wirst es nicht bereuen!</p>
<p>Schon bald erhältst du wunderbare Informationen zu deinem gewählten Thema.</p>