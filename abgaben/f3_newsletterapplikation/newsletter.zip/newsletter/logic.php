<?php

/*
 * TODO:
 * SQL-Query um Newsletter-Themen auszulesen (query schreiben & ausführen)
 */

$sql = "";


/*
 * TODO:
 * Resultat in Variable legen (MYSQLI_ASSOC)
 */

$newsletter_categories = "";


// Wenn Formular abgeschickt wurde



if(isset($_POST['email'])) {

    /*
     * TODO:
     * Inhalte von Formular sowie den aktuellen Timestamp auf Variablen legen
     */
    $fullname = "";
    $email = "";
    $newsletter_category = "";
    $created_at = "";


    /*
     * TODO
     * SQL Query schreiben um eingegebene Daten in die DB zu schreiben
     */
    $sql = "";

    // Query ausführen, wenn es fehlschlägt Error anzeigen
    mysqli_query($link, $sql) or die(mysqli_error($link));


    /*
     * TODO:
     * Session-Variable setzen und Benutzer als "eingetragen" markieren
     */


}

?>